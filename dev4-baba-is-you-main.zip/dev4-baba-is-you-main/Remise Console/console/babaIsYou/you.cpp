#include "you.h"

You::You(const std::string& name, const Direction& dir ) : Effect(name, dir){}


