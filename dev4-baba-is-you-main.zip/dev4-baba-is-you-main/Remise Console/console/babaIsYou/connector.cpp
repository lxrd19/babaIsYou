#include "connector.h"

Connector::Connector(const std::string& name, const Direction &dir) : Composant(name, dir){}
