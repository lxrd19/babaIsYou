#include "goop.h"

Goop::Goop(const std::string& name, const Direction &dir) : Element(name, dir){}


