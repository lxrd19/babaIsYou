#include "push.h"

Push::Push(const std::string& name, const Direction& dir) : Effect(name,  dir){}

