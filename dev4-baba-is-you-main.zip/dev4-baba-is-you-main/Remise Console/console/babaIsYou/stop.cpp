#include "stop.h"

Stop::Stop(const std::string& name, const Direction& dir ) : Effect(name, dir){}


