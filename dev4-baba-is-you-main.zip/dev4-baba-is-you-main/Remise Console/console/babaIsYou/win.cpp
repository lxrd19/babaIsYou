#include "win.h"

Win::Win(const std::string& name, const Direction& dir) : Effect(name, dir){}

