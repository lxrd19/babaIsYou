#include "best.h"

Best::Best(const std::string& name,  const Direction& dir) : Element(name, dir){}

