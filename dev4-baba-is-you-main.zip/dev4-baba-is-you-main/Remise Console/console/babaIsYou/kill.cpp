#include "kill.h"

Kill::Kill(const std::string& name, const Direction& dir) : Effect(name, dir){}


