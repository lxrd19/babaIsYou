#include "sink.h"

Sink::Sink(const std::string& name, const Direction& dir ) : Effect(name, dir){}


