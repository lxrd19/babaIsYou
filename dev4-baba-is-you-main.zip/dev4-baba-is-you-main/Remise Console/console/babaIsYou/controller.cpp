#include "controller.h"

Controller::Controller(Game* c, BoardView* b):  view(b), model(c)
{}
