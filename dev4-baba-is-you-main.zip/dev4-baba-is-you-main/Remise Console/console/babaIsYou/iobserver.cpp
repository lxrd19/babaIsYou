#include "iobserver.h"

iObserver::iObserver()
{

}
