#include "element.h"



Element::Element(const std::string& name, const Direction &dir) : Composant(name, dir){}

