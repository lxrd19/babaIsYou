#include "metal.h"

Metal::Metal(const std::string& name, const Direction& dir) : Element(name, dir){}


