#include "textobject.h"

TextObject::TextObject(const std::string& name, const Direction& dir) : Element(name, dir){}
