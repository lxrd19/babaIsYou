#include "baba.h"
#include "element.h"

Baba::Baba(const std::string& name, const Direction& dir) : Element(name, dir){}
