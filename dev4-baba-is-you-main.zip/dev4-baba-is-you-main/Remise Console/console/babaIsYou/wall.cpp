#include "wall.h"

Wall::Wall(const std::string& name, const Direction& dir) : Element(name, dir){}

