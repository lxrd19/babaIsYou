#include "isubject.h"

ISubject::~ISubject() {
}
