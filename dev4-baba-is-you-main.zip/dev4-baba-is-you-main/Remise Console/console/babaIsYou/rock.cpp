#include "rock.h"

Rock::Rock(const std::string& name, const Direction &dir) : Element(name, dir){}


