#include "effect.h"

Effect::Effect(const std::string& name, const Direction& dir) : Composant(name, dir){}
