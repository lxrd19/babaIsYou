# Project d'apprentissage au developement : Baba is You ©

**Version 1.0.0**


**Règle du jeu**

Baba is You 1
est un jeu de type puzzle.
À chaque niveau, le joueur, qui a le contrôle d’une élément sur le plateau, doit atteindre un objectif. La plupart du
temps, cet élément est le personnage « Baba », et il doit le déplacer sur un drapeau.
La particularité de ce jeu est que les règles du jeu sont littéralement des éléments placés sur
le plateau de jeu. Par exemple, sur le plateau illustré à la figure 1, le joueur contrôle Baba parce
que trois blocs « Baba », « is » et « you » sont placés côte à côte, et implémentent donc la règle
« le joueur contrôle Baba ». L’objectif à atteindre est le drapeau parce que trois blocs « Flag »,
« is » et « win » sont placés côte à côte, etc.
Ainsi, les règles du jeu peuvent être modifiées à la volée, en poussant des éléments de règles
soit pour les rompre, soit pour en créer. Par exemple, sur le plateau illustré à la figure 1, en l’état,
Baba ne peut pas traverser les murs, parce qu’une règle « Wall » « is » « stop » est présente sur
le plateau. Toutefois, si elle pousse l’un des trois éléments « Wall », « is » ou « stop » vers le bas,
elle brise cette règle, et elle peut donc traverser les murs pour tenter d’atteindre son objectif.


**Implémentation**

En premier, une implémentation console sera faite,
avant de passer par l'implémentation graphique.


## License & copyright

© Butt Hasnain & Mawuvi Koffi, 54383 & 54309 HE2B - ESI
