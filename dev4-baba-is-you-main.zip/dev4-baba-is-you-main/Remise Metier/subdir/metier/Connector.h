#ifndef CONNECTOR_H
#define CONNECTOR_H

/**
 * @brief The Connector enum the connector of a rule.
 * it is the second element of a rule object.
 */
enum class Connector{
    IS
};

#endif // CONNECTOR_H
