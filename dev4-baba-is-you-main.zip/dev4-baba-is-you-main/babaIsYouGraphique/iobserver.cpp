//#include "iobserver.h"

//IObserver::IObserver() noexcept
//{}
