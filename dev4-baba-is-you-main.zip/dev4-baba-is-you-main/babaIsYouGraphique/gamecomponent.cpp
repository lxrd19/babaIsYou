//#include "gamecomponent.h"

//gameComponent::gameComponent()
//{

//}
