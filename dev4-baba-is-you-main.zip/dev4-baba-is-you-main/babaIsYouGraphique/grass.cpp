#include "grass.h"

Grass::Grass(const std::string& name, const Direction& dir) : Element(name, dir){}

