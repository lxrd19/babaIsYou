#include "lava.h"

Lava::Lava(const std::string& name, const Direction& dir) : Element(name, dir){}



