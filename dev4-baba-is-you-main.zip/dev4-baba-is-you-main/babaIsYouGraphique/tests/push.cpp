#include "push.h"

Push::Push(const std::string& name, const Direction& dir) : Effect(name,  dir){}

//void Push::apply(Game& game, Direction dir){
//    std::cout << "apply Goop" << std::endl;
//};
