/**
 * Runs this file to run the tests.
 * <p>
 * The <code>main</code> function is defined in the catch.hpp header
 */

#define CATCH_CONFIG_MAIN //provides main
#include "catch.hpp" //every file including this header you have its tests ran
