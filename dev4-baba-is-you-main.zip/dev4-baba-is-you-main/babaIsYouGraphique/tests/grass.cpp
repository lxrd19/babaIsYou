#include "grass.h"

Grass::Grass(const std::string& name, const Direction& dir) : Element(name, dir){}

//Direction Grass::getDir(){
//    return Element::getDir();
//}

//std::string Grass::getName(){
//    return Element::getName();
//}
