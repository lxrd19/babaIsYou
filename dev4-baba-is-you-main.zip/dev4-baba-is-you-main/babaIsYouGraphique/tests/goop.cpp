#include "goop.h"

Goop::Goop(const std::string& name, const Direction &dir) : Element(name, dir){}

//std::string Goop::getName(){
//    return Element::getName();
//}

