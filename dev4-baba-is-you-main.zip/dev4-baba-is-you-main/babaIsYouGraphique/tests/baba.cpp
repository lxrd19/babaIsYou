#include "baba.h"
#include "element.h"

Baba::Baba(const std::string& name, const Direction& dir) : Element(name, dir){}


//Direction Baba::getDir(){
//    return Element::getDir();
//}

//std::string Baba::getName(){
//    return Element::getName();
//}
