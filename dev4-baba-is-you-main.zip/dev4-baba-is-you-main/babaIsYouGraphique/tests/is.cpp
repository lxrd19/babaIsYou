#include "is.h"

Is::Is(const std::string& name, const Direction& dir) : Connector(name, dir){}


//void Is::apply(Game& game, Direction dir){
//    std::cout << "apply Goop" << std::endl;
//};
