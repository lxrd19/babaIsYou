#include "sink.h"
#include "controller.h"

Sink::Sink(const std::string& name, const Direction& dir ) : Effect(name, dir){}


//void Sink::apply(Game& game, Direction dir){
//    std::cout << "apply Goop" << std::endl;
//};
