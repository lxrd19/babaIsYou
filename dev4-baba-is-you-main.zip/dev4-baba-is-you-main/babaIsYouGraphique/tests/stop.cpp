#include "stop.h"

Stop::Stop(const std::string& name, const Direction& dir ) : Effect(name, dir){}


//void Stop::apply(Game& game, Direction dir){
//    std::cout << "apply Goop" << std::endl;
//};
