#include "flag.h"

Flag::Flag(const std::string& name, const Direction &dir) : Element(name, dir){}



